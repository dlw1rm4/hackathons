import java.util.*;


class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("Welcome to your imaginary life simulation c: ");

    student stu = new student();
    choices myChoices = new choices();
    ArrayList<String> questionsList = myChoices.prompt();

    int badFood;
    for(int day = 1; day <= 3; day++)
    {
      stu.day();
      stu.sleep();
      System.out.println("Day " + day + " has ended.");
    
    }
  
    System.out.println("\nYour stats:");
    stu.stats();
  }
}

// returns lists of options for each part of the day
class choices {
  ArrayList<String> bFoods = new ArrayList<>(Arrays.asList("Bacon & Eggs", "Avocado Toast", "McDonalds", "Whole Grain Cereal"));
  ArrayList<String> lFoods = new ArrayList<>(Arrays.asList("Caesar Salad", "School Lunch", "Chick-Fil-A", "Tuna Sandwich"));
  ArrayList<String> dFoods = new ArrayList<>(Arrays.asList("Whatever Mom Makes", "In-N-Out", "Sushi", "Carne Asada Tacos"));
  ArrayList<String> snacks = new ArrayList<>(Arrays.asList("Fruits", "Chips", "Nuts", "Candy"));
  ArrayList<String> afterSchool = new ArrayList<>(Arrays.asList("Go to work", "Study", "Hang out with friends", "Play video games", "Relax at home"));
  ArrayList<String> afterDinner = new ArrayList<>(Arrays.asList("Go to sleep", "Study", "Play video games", "Read web novels"));
  ArrayList<String> questions = new ArrayList<>(Arrays.asList("What will you have for breakfast?", "It's time for school!", "It's now lunchtime. Choose what to eat:", "School's out! What do you want to do now?", "Dinner is now. What will you be having?","It's the end of the day. What now?"));

  public choices()
  {
    
  }
  public ArrayList<String> prompt()
  {
    return questions;
  }

  public ArrayList<String> breakfast()
  {
    return bFoods;
  }
  public ArrayList<String> lunch()
  {
    return lFoods;
  }
  public ArrayList<String> dinner()
  {
    return dFoods;
  }
  public ArrayList<String> snack()
  {
    return snacks;
  }
  public ArrayList<String> afterSchool()
  {
    return afterSchool;
  }
  public ArrayList<String> afterDinner()
  {
    return afterDinner;
  }
}

class student {
  choices myChoices;
  Scanner scan;
  ArrayList<String> questionsList;
  int happy, work, food, sleep, penalty, badFood, health;
  String hour, minute, period;

  // constructor
  public student()
  {
    scan = new Scanner(System.in);
    myChoices = new choices();
    questionsList = myChoices.prompt();
    happy = 100;
    food = 50;
    sleep = 100;
    work = 0;
    badFood = 0;
    penalty = 0; // increments every time a bad decision is made
    hour = "7";
    minute = "00";
    period = "AM";
  }

  // simulate a day
  public void day()
  {
    badFood = 0;
    for(int event = 0; event <= 5; event++)
      {
        System.out.println();
        printStatus();
        System.out.println();
        System.out.println(questionsList.get(event));
        switch(event)
          {
            case 0:
              breakfast();
              break;
            
            case 1:
              if(school())
                System.out.println("You stayed focused and learned a lot during your classes.");
              else
                System.out.println("You kept falling asleep during class and didn't pay attention at all.\n");
              setTime("1","35","PM");
              break;
            
            case 2:
              lunch();
              break;
            
            case 3:
              afterSchool();
              break;

            case 4:
              dinner();
              break;

            case 5: // after dinner
              afterDinner();
              break;
              
            default: // this should not run
              System.out.println("error");
              break;
          }

        if(badFood >= 3) // if 3 unhealthy meals eaten or skipped
          penalty++;
        checkHungry();
        if(checkSleep())
        {
          System.out.println("You are exhausted and immediately go to sleep");
          break;
        }
      }
  }
  
   public void breakfast()
     {
     printOptions(myChoices.breakfast());
              switch(scan.nextInt())
              {
                case 1: // bacon & eggs
                  eat(20);
                  break;
                case 2: // avocado toast
                  eat(20);
                  break;
                case 3: // mcdonalds
                  eat(25);
                  badFood ++;
                  break;
                case 4: // whole grain cereal
                  eat(20);
                   break;
                default:
                  eat(-10);
                  badFood ++; // not eating anything
                  break;
              }
              System.out.println("Chomp chomp.");
              setTime("8","35","AM");
     }
      public void lunch()
        {
        printOptions(myChoices.lunch());
              switch(scan.nextInt())
              {
                case 1: // salad
                  eat(25);
                  break;
                case 2: // school lunch
                  eat(35);
                  break;
                case 3: // chick fil a
                  eat(35);
                  badFood ++;
                  break;
                case 4: // tuna sandwich
                  eat(30);
                  break;
                default:
                  eat(-20);
                  badFood ++; // not eating anything
                  break;
              }
              System.out.println("Yum!");
              setTime("3","45","PM");
        }
    public void afterSchool()
      {
      printOptions(myChoices.afterSchool());
              switch(scan.nextInt())
              {
                case 1: // go to work
                  work();
                  System.out.println("Great job!");
                  break;
                case 2: // study
                  study();
                  System.out.println("Great study session!");
                  break;
                case 3: // hang out with friends
                  friends();
                  break;
                case 4: // play video games
                  games();
                  System.out.println("That was fun!");
                  break;
                case 5: // relax at home
                  nap();
                  break;
                default: // do nothing
                  eat(-15);
                  break;
              }   
              setTime("7","00","PM");
      }
    
    public void dinner()
    {
      printOptions(myChoices.dinner());
      switch(scan.nextInt())
      {
        case 1: // whatever mom makes
          eat(30);
          break;
        case 2: // in n out
          eat(35);
          badFood++;
          break;
        case 3: // sushi
          eat(30);
          break;
        case 4: // tacos
          eat(30);
          break;
        default: // don't eat
          eat(-15);
          badFood++;
          break;
       }
      setTime("8","00","PM"); //omg dear evan hansen
    }

  public void afterDinner()
  {
    printOptions(myChoices.afterDinner());
    switch(scan.nextInt())
    {
      case 1: // go to sleep
        System.out.println("Day complete!");
        break;
      case 2: // stay up studying
        study();
        System.out.println("Gotta study hard!");
        break;
      case 3: // play video games
        games();
        System.out.println("Completed gaming session!");
        break;
      case 4: // read web novels
        read();
        System.out.println("Read everything!");
        break;
      default:
        break;
    }
    setTime("7","00","AM");
  }

    

  // methods that provide info
  public void printStatus()
  {
    System.out.println(hour + ":" + minute + " " + period);
    if(food == 0)
      System.out.println("You are starving");
    else if(food < 30)
      System.out.println("You are hungry");
    else if(food >= 100)
      System.out.println("You are full");
    if(sleep < 30)
      System.out.println("You are tired");
    else if(sleep > 80)
      System.out.println("You are full of energy");
    if(work > 50)
      System.out.println("You feel accomplished");
    if(happy < 30)
      System.out.println("You feel depressed"); 
  }

  public void printOptions(ArrayList<String> list)
  {
      for(int index = 1; index < list.size()+1; index++)
      {
          System.out.println(index + " " + list.get(index-1));
      }
  }



  
  // methods that do activities
  public boolean school()
  {
    sleep -= 40;
    food -= 30;
    if(sleep > 40)
      return true;
    else
    {
      penalty++;
      return false;
    }
    
  }
  
  public void work()
  {
    sleep -= 30;
    work += 30;
    food -= 30;
    happy -= 30;
  }

  public void study()
  {
    sleep -= 30;
    work += 30;
    food -= 30;
    happy -= 30;
  }
  
  public void friends() // friendship is magic
  {
    sleep -= 20;
    food -= 20;
    happy += 40;
  }
  
  public void games()
  {
    penalty += 1;
    sleep -= 20;
    happy += 20;
    food -= 15;
  }
  
  public void nap()
  {
    sleep += 20;
    food -= 10;
  }

  public void read()
  {
    happy += 20;
    sleep -= 20;
    penalty++;
  }
  

  
  
   // general actions & checks
  public void sleep() // sleep until next day
  {
    sleep += 100;
    if(sleep > 100)
      sleep = 100;
    food -= 20;
  }
  
  public void eat(int value)
  {
    food += value;
  }

  public boolean checkSleep() // returns true if exhausted
  {
    if(sleep < 0)
    {
      happy -= sleep; // time stayed up late is deducted from happiness
      penalty ++;
      return true;
    }
    else
      return false;
  }
  
  public void checkHungry()
  {
    if(food < 0)
    {
      happy += food;
      food = 0;
      penalty ++;
    }
    if(food > 100)
      food = 100;
  }
  
  public void addPenalty()
  {
    penalty++;
  }

  public void setTime(String h, String m, String p)
  {
    hour = h;
    minute = m;
    period = p;
  }

  public void stats()
   {
     System.out.println("Happy: " + happy);
     System.out.println("Sleep: " + sleep);
     System.out.println("Food: " + food);
     System.out.println("Work: " + work);
     System.out.println("Penalty/Penalties: " + penalty);
     
     int health = 0;
     if(happy > 80)
       health++;
     else if(sleep > 90)
       health++;
     else if(food > 80)
       health++;
     else if(work > 85)
       health++;

     health -= penalty / 2;
       
     if(health >= 3)
       System.out.println("Overall, you're healthy! Congrats, you win!");
     else
       System.out.println("Overall, you're unhealthy. Whoops :c");
   }
}
